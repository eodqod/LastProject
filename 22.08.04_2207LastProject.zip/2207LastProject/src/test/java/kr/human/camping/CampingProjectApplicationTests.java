package kr.human.camping;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CampingProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
