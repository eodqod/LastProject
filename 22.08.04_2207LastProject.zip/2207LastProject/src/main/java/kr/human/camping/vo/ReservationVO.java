package kr.human.camping.vo;

import lombok.Data;

@Data
public class ReservationVO {
	private String id;
	private int roomidx;
	private String email;
}
